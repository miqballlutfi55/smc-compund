package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.SavedPlan
import com.example.data.SavedPlanRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.floor

enum class TradeResult { PROJECTED, WIN, LOSS }

data class DailyProjection(
    val day: Int,
    val startBalance: Double,
    val lotSize: Double,
    val profitLoss: Double,
    val endBalance: Double,
    val result: TradeResult
)

data class CompoundState(
    val initialBalance: String = "1000",
    val targetPips: String = "100", 
    val stepSize: String = "100",
    val initialLot: String = "", 
    val maxLot: String = "50",
    val totalTrades: String = "30",
    val rrRatio: String = "",
    val kursIdr: String = "16200",
    val overrides: Map<Int, TradeResult> = emptyMap()
)

data class ExecutionState(
    val currentBalance: String = "1000",
    val riskPerTradePercent: String = "1",
    val slPips: String = "50",
    val tpPips: String = "50",
    val rewardPercent: String = "1",
    val kursIdr: String = "16000"
)

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SavedPlanRepository

    init {
        val dao = AppDatabase.getDatabase(application).savedPlanDao()
        repository = SavedPlanRepository(dao)
    }

    val savedPlans: StateFlow<List<SavedPlan>> = repository.allPlans.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _compoundState = MutableStateFlow(CompoundState())
    val compoundState: StateFlow<CompoundState> = _compoundState.asStateFlow()

    private val _executionState = MutableStateFlow(ExecutionState())
    val executionState: StateFlow<ExecutionState> = _executionState.asStateFlow()

    // Compound Update Methods
    fun updateCompoundState(update: CompoundState.() -> CompoundState) {
        _compoundState.update { it.update() }
    }

    fun setOverride(day: Int, result: TradeResult) {
        val currentOverrides = _compoundState.value.overrides.toMutableMap()
        currentOverrides[day] = result
        _compoundState.update { it.copy(overrides = currentOverrides) }
    }

    fun clearOverrides() {
        _compoundState.update { it.copy(overrides = emptyMap()) }
    }
    
    fun loadPlan(plan: SavedPlan) {
        _compoundState.update { 
            it.copy(
                initialBalance = plan.initialBalance.toInt().toString(),
                targetPips = plan.pipsTarget.toInt().toString(),
                stepSize = plan.stepSize.toInt().toString(),
                initialLot = plan.initialLot.toString(),
                maxLot = plan.maxLot.toString(),
                totalTrades = plan.totalTrades.toString(),
                rrRatio = plan.riskRewardRatio.toString(),
                kursIdr = plan.kursIdr.toInt().toString(),
                overrides = emptyMap()
            )
        }
    }

    fun saveCurrentPlan(planName: String) {
        val s = _compoundState.value
        val initBal = s.initialBalance.toDoubleOrNull() ?: 1000.0
        val tgtPips = s.targetPips.toDoubleOrNull() ?: 100.0
        val stepAmt = s.stepSize.toDoubleOrNull() ?: 100.0
        val initLotStr = s.initialLot.trim()
        val initLot = if (initLotStr.isEmpty()) 0.01 else (initLotStr.toDoubleOrNull() ?: 0.01)
        
        viewModelScope.launch {
            repository.insert(
                SavedPlan(
                    planName = planName,
                    initialBalance = initBal,
                    pipsTarget = tgtPips,
                    stepSize = stepAmt,
                    initialLot = initLot,
                    maxLot = s.maxLot.toDoubleOrNull() ?: 50.0,
                    totalTrades = s.totalTrades.toIntOrNull() ?: 30,
                    riskRewardRatio = s.rrRatio.toDoubleOrNull() ?: 1.0,
                    kursIdr = s.kursIdr.toDoubleOrNull() ?: 16200.0
                )
            )
        }
    }

    fun deletePlan(plan: SavedPlan) {
        viewModelScope.launch {
            repository.deleteById(plan.id)
        }
    }

    fun calculateProjections(state: CompoundState): List<DailyProjection> {
        val projections = mutableListOf<DailyProjection>()
        
        val initBal = state.initialBalance.toDoubleOrNull() ?: 1000.0
        val tgtPips = state.targetPips.toDoubleOrNull() ?: 100.0
        val stepAmt = state.stepSize.toDoubleOrNull() ?: 100.0
        val initLotStr = state.initialLot.trim()
        val initLot = if (initLotStr.isEmpty()) 0.01 else (initLotStr.toDoubleOrNull() ?: 0.01)
        val maxLot = state.maxLot.toDoubleOrNull() ?: 50.0
        val rrStr = state.rrRatio.trim()
        val rr = if (rrStr.isEmpty()) 1.0 else (rrStr.toDoubleOrNull() ?: 1.0)
        val totalTrades = state.totalTrades.toIntOrNull() ?: 30
        
        // standard Pip Value is $10 per lot for 1 pip.
        val standardPipValue = 10.0
        
        var currentBalance = initBal

        for (day in 1..totalTrades) {
            val result = state.overrides[day] ?: TradeResult.PROJECTED
            
            // Dynamic Lot Size with Target Profit Step
            val profitMade = Math.max(0.0, currentBalance - initBal)
            val steps = if (stepAmt > 0) floor(profitMade / stepAmt) else 0.0
            var currentLot = initLot + (steps * initLot)
            
            if (currentLot < initLot) currentLot = initLot
            if (currentLot > maxLot) currentLot = maxLot

            val winAmount = currentLot * tgtPips * standardPipValue
            val lossAmount = winAmount / rr

            val profitLoss = when (result) {
                TradeResult.WIN, TradeResult.PROJECTED -> winAmount
                TradeResult.LOSS -> -lossAmount
            }

            val endBalance = currentBalance + profitLoss
            
            projections.add(
                DailyProjection(
                    day = day,
                    startBalance = currentBalance,
                    lotSize = currentLot,
                    profitLoss = profitLoss,
                    endBalance = endBalance,
                    result = result
                )
            )
            
            currentBalance = endBalance
            if (currentBalance <= 0) break
        }
        return projections
    }

    // Execution Update Methods
    fun updateExecutionState(update: ExecutionState.() -> ExecutionState) {
        _executionState.update { it.update() }
    }
    
    fun syncTpFromReward(rewardStr: String) {
        _executionState.update { state ->
            val rewardP = rewardStr.toDoubleOrNull() ?: 0.0
            val bal = state.currentBalance.toDoubleOrNull() ?: 0.0
            val riskP = state.riskPerTradePercent.toDoubleOrNull() ?: 0.0
            val slP = state.slPips.toDoubleOrNull() ?: 0.0
            
            val riskAmount = bal * (riskP / 100.0)
            val lot = if (slP > 0) riskAmount / (slP * 10.0) else 0.0
            
            val rewardAmount = bal * (rewardP / 100.0)
            val tpNeeded = if (lot > 0) rewardAmount / (lot * 10.0) else 0.0
            
            state.copy(rewardPercent = rewardStr, tpPips = String.format(java.util.Locale.US, "%.1f", tpNeeded))
        }
    }

    fun syncRewardFromTp(tpStr: String) {
        _executionState.update { state ->
            val tp = tpStr.toDoubleOrNull() ?: 0.0
            val bal = state.currentBalance.toDoubleOrNull() ?: 0.0
            val riskP = state.riskPerTradePercent.toDoubleOrNull() ?: 0.0
            val slP = state.slPips.toDoubleOrNull() ?: 0.0
            
            val riskAmount = bal * (riskP / 100.0)
            val lot = if (slP > 0) riskAmount / (slP * 10.0) else 0.0
            
            val expectedWin = lot * tp * 10.0
            val rewP = if (bal > 0) (expectedWin / bal) * 100.0 else 0.0
            
            state.copy(tpPips = tpStr, rewardPercent = String.format(java.util.Locale.US, "%.2f", rewP))
        }
    }
    
    fun useLastProjectionBalance() {
        val projections = calculateProjections(_compoundState.value)
        val lastBalance = projections.lastOrNull()?.endBalance ?: (_compoundState.value.initialBalance.toDoubleOrNull() ?: 1000.0)
        _executionState.update { it.copy(currentBalance = lastBalance.toInt().toString(), kursIdr = _compoundState.value.kursIdr) }
    }
}
