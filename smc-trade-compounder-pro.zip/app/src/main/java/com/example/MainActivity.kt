package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.tabs.*
import com.example.ui.theme.AppTheme
import com.example.viewmodel.AppViewModel
import kotlinx.serialization.Serializable

@Serializable object CompoundRoute
@Serializable object ExecutionRoute
@Serializable object AnalyticsRoute
@Serializable object SavedPlansRoute

class MainActivity : ComponentActivity() {
    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                MainScreen(viewModel)
            }
        }
    }
}

@Composable
fun MainScreen(viewModel: AppViewModel) {
    val navController = rememberNavController()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = com.example.ui.theme.DarkBackground,
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                NavigationBar(
                    modifier = Modifier.clip(RoundedCornerShape(24.dp)),
                    containerColor = com.example.ui.theme.CardBackground,
                    contentColor = com.example.ui.theme.TextSecondary,
                    tonalElevation = 8.dp
                ) {
                    // Compound Tab
                    val isCompound = currentDestination?.hierarchy?.any { it.route?.contains("Compound") == true } == true
                    NavigationBarItem(
                        selected = isCompound,
                        onClick = { navController.navigate(CompoundRoute) { popUpTo(CompoundRoute) { inclusive = false } } },
                        icon = { Icon(Icons.Default.Build, contentDescription = "Compound") },
                        label = { Text("Compound") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = com.example.ui.theme.DarkBackground,
                            selectedTextColor = com.example.ui.theme.TextPrimary,
                            indicatorColor = com.example.ui.theme.NeonGreen,
                            unselectedIconColor = com.example.ui.theme.TextSecondary,
                            unselectedTextColor = com.example.ui.theme.TextSecondary
                        )
                    )

                    // Execution Tab
                    val isExecution = currentDestination?.hierarchy?.any { it.route?.contains("Execution") == true } == true
                    NavigationBarItem(
                        selected = isExecution,
                        onClick = { navController.navigate(ExecutionRoute) { popUpTo(CompoundRoute) } },
                        icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Execution") },
                        label = { Text("Execution") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = com.example.ui.theme.DarkBackground,
                            selectedTextColor = com.example.ui.theme.TextPrimary,
                            indicatorColor = com.example.ui.theme.ElectricBlue,
                            unselectedIconColor = com.example.ui.theme.TextSecondary,
                            unselectedTextColor = com.example.ui.theme.TextSecondary
                        )
                    )

                    // Analytics Tab
                    val isAnalytics = currentDestination?.hierarchy?.any { it.route?.contains("Analytics") == true } == true
                    NavigationBarItem(
                        selected = isAnalytics,
                        onClick = { navController.navigate(AnalyticsRoute) { popUpTo(CompoundRoute) } },
                        icon = { Icon(Icons.Default.Info, contentDescription = "Analytics") },
                        label = { Text("Analytics") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = com.example.ui.theme.DarkBackground,
                            selectedTextColor = com.example.ui.theme.TextPrimary,
                            indicatorColor = com.example.ui.theme.CrimsonRed,
                            unselectedIconColor = com.example.ui.theme.TextSecondary,
                            unselectedTextColor = com.example.ui.theme.TextSecondary
                        )
                    )

                    // Saved Plans Tab
                    val isSaved = currentDestination?.hierarchy?.any { it.route?.contains("SavedPlans") == true } == true
                    NavigationBarItem(
                        selected = isSaved,
                        onClick = { navController.navigate(SavedPlansRoute) { popUpTo(CompoundRoute) } },
                        icon = { Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Saved Plans") },
                        label = { Text("Plans") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = com.example.ui.theme.TextPrimary,
                            selectedTextColor = com.example.ui.theme.TextPrimary,
                            indicatorColor = com.example.ui.theme.OutlineColor,
                            unselectedIconColor = com.example.ui.theme.TextSecondary,
                            unselectedTextColor = com.example.ui.theme.TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = CompoundRoute,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable<CompoundRoute> { CompoundScreen(viewModel) }
            composable<ExecutionRoute> { ExecutionScreen(viewModel) }
            composable<AnalyticsRoute> { AnalyticsScreen(viewModel) }
            composable<SavedPlansRoute> { 
                SavedPlansScreen(viewModel, onPlanLoaded = {
                    navController.navigate(CompoundRoute) {
                        popUpTo(CompoundRoute) { inclusive = true }
                    }
                }) 
            }
        }
    }
}
