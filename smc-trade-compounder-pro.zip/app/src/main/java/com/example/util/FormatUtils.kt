package com.example.util

import java.text.NumberFormat
import java.util.Locale

object FormatUtils {
    private val usdFormatter = NumberFormat.getCurrencyInstance(Locale.US)
    private val idrFormatter = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("id-ID"))

    fun formatUsd(amount: Double): String {
        return usdFormatter.format(amount)
    }

    fun formatIdr(amount: Double): String {
        val formatted = idrFormatter.format(amount)
        return formatted.replace("Rp", "Rp ").replace(",00", "")
    }

    fun formatLot(lot: Double): String {
        return String.format(Locale.US, "%.2f", lot)
    }

    fun formatPercent(percent: Double): String {
        return String.format(Locale.US, "%,.2f", percent)
    }
}
