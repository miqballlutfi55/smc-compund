package com.example.data

import kotlinx.coroutines.flow.Flow

class SavedPlanRepository(private val dao: SavedPlanDao) {
    val allPlans: Flow<List<SavedPlan>> = dao.getAllPlans()

    suspend fun insert(plan: SavedPlan) = dao.insertPlan(plan)

    suspend fun deleteById(id: Int) = dao.deletePlanById(id)
}
