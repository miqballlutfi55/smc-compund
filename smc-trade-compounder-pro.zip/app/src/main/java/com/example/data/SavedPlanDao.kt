package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedPlanDao {
    @Query("SELECT * FROM saved_plans ORDER BY timestamp DESC")
    fun getAllPlans(): Flow<List<SavedPlan>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlan(plan: SavedPlan)

    @Query("DELETE FROM saved_plans WHERE id = :id")
    suspend fun deletePlanById(id: Int)
}
