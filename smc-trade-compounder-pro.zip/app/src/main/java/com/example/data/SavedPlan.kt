package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "saved_plans")
@Serializable
data class SavedPlan(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val planName: String,
    val initialBalance: Double,
    val pipsTarget: Double,
    val stepSize: Double,
    val initialLot: Double,
    val maxLot: Double,
    val totalTrades: Int,
    val riskRewardRatio: Double,
    val kursIdr: Double,
    val timestamp: Long = System.currentTimeMillis()
)
