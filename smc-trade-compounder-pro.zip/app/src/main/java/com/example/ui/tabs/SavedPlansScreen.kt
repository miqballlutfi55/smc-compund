package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SMCHeader
import com.example.ui.theme.*
import com.example.util.FormatUtils
import com.example.viewmodel.AppViewModel

@Composable
fun SavedPlansScreen(viewModel: AppViewModel, onPlanLoaded: () -> Unit) {
    val plans by viewModel.savedPlans.collectAsState()
    val haptic = LocalHapticFeedback.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
    ) {
        SMCHeader("Saved Plans")
        
        if (plans.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No saved plans yet. Create one on Compound tab.", color = TextSecondary)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(plans, key = { it.id }) { plan ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.loadPlan(plan)
                                onPlanLoaded()
                            }
                            .clip(RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(plan.planName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                Spacer(Modifier.height(4.dp))
                                Row {
                                    Text("From: ${FormatUtils.formatUsd(plan.initialBalance)}", color = TextSecondary, fontSize = 14.sp)
                                    Spacer(Modifier.width(16.dp))
                                    Text("Target: ${FormatUtils.formatUsd(plan.stepSize)}", color = TextSecondary, fontSize = 14.sp)
                                }
                            }
                            IconButton(onClick = { 
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.deletePlan(plan) 
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Plan", tint = CrimsonRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
