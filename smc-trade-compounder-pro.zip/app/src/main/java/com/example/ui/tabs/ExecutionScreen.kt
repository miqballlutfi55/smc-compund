package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SMCHeader
import com.example.ui.SMCInputCard
import com.example.ui.SMCTextField
import com.example.ui.theme.*
import com.example.util.FormatUtils
import com.example.viewmodel.AppViewModel
import kotlin.math.floor

@Composable
fun ExecutionScreen(viewModel: AppViewModel) {
    val state by viewModel.executionState.collectAsState()
    val compoundState by viewModel.compoundState.collectAsState()
    val haptic = LocalHapticFeedback.current

    val currentBalanceD = state.currentBalance.toDoubleOrNull() ?: 0.0
    val riskPercentD = state.riskPerTradePercent.toDoubleOrNull() ?: 0.0
    val slPipsD = state.slPips.toDoubleOrNull() ?: 0.0
    val tpPipsD = state.tpPips.toDoubleOrNull() ?: 0.0
    val kursIdrD = state.kursIdr.toDoubleOrNull() ?: 0.0

    // Calculation Logic
    val standardPipValue = 10.0
    val riskAmount = currentBalanceD * (riskPercentD / 100.0)
    // Lot = RiskAmount / (SL Pips * 10)
    val calcLot = if (slPipsD > 0) riskAmount / (slPipsD * standardPipValue) else 0.0
    val recommendedLot = floor(calcLot * 100) / 100.0 // Round down to 2 decimals

    val potentialLoss = recommendedLot * slPipsD * standardPipValue
    val potentialWin = recommendedLot * tpPipsD * standardPipValue
    val actualRR = if (potentialLoss > 0) potentialWin / potentialLoss else 0.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        SMCHeader("Execution Lot Calc")

        Button(
            onClick = { 
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                viewModel.useLastProjectionBalance() 
            },
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlueDark)
        ) {
            Text("Auto-Sync dari Projection Timeline")
        }

        val balanceIdrText = "≈ " + FormatUtils.formatIdr(currentBalanceD * kursIdrD)
        
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SMCInputCard("CURRENT BALANCE (\$)", state.currentBalance, { viewModel.updateExecutionState { copy(currentBalance = it) } }, Modifier.weight(1f), subText = balanceIdrText, formatAsNumber = true)
            SMCInputCard("KURS IDR", state.kursIdr, { viewModel.updateExecutionState { copy(kursIdr = it) } }, Modifier.weight(1f), formatAsNumber = true)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SMCInputCard("RISK (%)", state.riskPerTradePercent, { viewModel.updateExecutionState { copy(riskPerTradePercent = it) } }, Modifier.weight(1f), formatAsNumber = true)
            SMCInputCard("SL (PIPS)", state.slPips, { viewModel.updateExecutionState { copy(slPips = it) } }, Modifier.weight(1f), formatAsNumber = true)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SMCInputCard("TP (PIPS)", state.tpPips, { viewModel.syncRewardFromTp(it) }, Modifier.weight(1f), formatAsNumber = true)
            SMCInputCard("REWARD (%)", state.rewardPercent, { viewModel.syncTpFromReward(it) }, Modifier.weight(1f), formatAsNumber = true)
        }
        
        Spacer(Modifier.height(24.dp))
        
        // Output Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
            shape = RoundedCornerShape(32.dp)
        ) {
            Box(modifier = Modifier.background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(CardBackground, androidx.compose.ui.graphics.Color(0xFF15161A))))) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("RECOMMENDED LOT", color = TextSecondary, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        FormatUtils.formatLot(recommendedLot),
                        color = ElectricBlue,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    
                    Spacer(Modifier.height(24.dp))
                    
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Potential Loss", color = TextSecondary)
                            Text("-${FormatUtils.formatUsd(potentialLoss)}", color = CrimsonRed, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text(FormatUtils.formatIdr(potentialLoss * kursIdrD), color = CrimsonRed.copy(alpha=0.7f), fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Potential Win", color = TextSecondary)
                            Text("+${FormatUtils.formatUsd(potentialWin)}", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text(FormatUtils.formatIdr(potentialWin * kursIdrD), color = NeonGreen.copy(alpha=0.7f), fontSize = 12.sp)
                        }
                    }
                    
                    Spacer(Modifier.height(16.dp))
                    HorizontalDivider(color = OutlineColor)
                    Spacer(Modifier.height(16.dp))
                    
                    Text(
                        "Actual RR = 1 : ${String.format("%.2f", actualRR)}",
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
