package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.OffsetMapping
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

@Composable
fun SMCHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary,
        modifier = Modifier.padding(bottom = 16.dp)
    )
}

@Composable
fun SMCTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Number
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = TextSecondary) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = ElectricBlue,
            unfocusedBorderColor = OutlineColor,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedContainerColor = CardBackground,
            unfocusedContainerColor = CardBackground
        ),
        singleLine = true
    )
}

class NumberCommaTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val originalText = text.text
        if (originalText.isEmpty() || originalText.contains("-") || originalText.count { it == '.' } > 1) {
            return TransformedText(text, OffsetMapping.Identity)
        }
        
        val isDecimal = originalText.contains('.')
        val parts = originalText.split('.')
        val integerPart = parts[0]
        val fractionPart = if (parts.size > 1) parts[1] else ""
        
        val formattedIntegerPart = try {
            val formatter = DecimalFormat("#,###", DecimalFormatSymbols(Locale.US))
            formatter.format(integerPart.toLongOrNull() ?: 0L)
        } catch (e: Exception) {
            integerPart
        }
        
        val resultText = if (isDecimal) {
            if (parts.size == 1) "$formattedIntegerPart." else "$formattedIntegerPart.$fractionPart"
        } else {
            if (originalText.isEmpty()) "" else formattedIntegerPart
        }

        val offsetMapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                if (offset <= 0) return 0
                val textBeforeOffset = originalText.substring(0, offset)
                val isBeforeDec = !textBeforeOffset.contains('.')
                if (!isBeforeDec) {
                    val decIndex = originalText.indexOf('.')
                    val originalBeforeDecCount = decIndex.coerceAtLeast(0)
                    val formattedBeforeDecCount = formattedIntegerPart.length
                    return offset + (formattedBeforeDecCount - originalBeforeDecCount)
                } else {
                    val originalBeforeOffsetCount = offset
                    val formattedOffsetText = try {
                        val formatter = DecimalFormat("#,###", DecimalFormatSymbols(Locale.US))
                        formatter.format(textBeforeOffset.toLongOrNull() ?: 0L)
                    } catch (e: Exception) {
                        textBeforeOffset
                    }
                    return formattedOffsetText.length.coerceAtMost(resultText.length)
                }
            }
            override fun transformedToOriginal(offset: Int): Int {
                if (offset <= 0) return 0
                val textBeforeOffset = resultText.substring(0, offset.coerceAtMost(resultText.length))
                val stripped = textBeforeOffset.replace(",", "")
                return stripped.length.coerceAtMost(originalText.length)
            }
        }

        return TransformedText(AnnotatedString(resultText), offsetMapping)
    }
}

@Composable
fun SMCInputCard(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Number,
    placeholder: String = "",
    subText: String? = null,
    formatAsNumber: Boolean = false
) {
    Card(
        modifier = modifier.defaultMinSize(minHeight = 88.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = label.uppercase(), 
                color = Color(0xFFA0A0A0), 
                fontSize = 10.sp, 
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            BasicTextField(
                value = value,
                onValueChange = { newValue ->
                    // Always allow updating, limit characters depending on logic if needed
                    val sanitized = if (formatAsNumber) newValue.replace(",", "") else newValue
                    onValueChange(sanitized)
                },
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                ),
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                visualTransformation = if (formatAsNumber) NumberCommaTransformation() else VisualTransformation.None,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                singleLine = true,
                cursorBrush = SolidColor(Color.White),
                decorationBox = { innerTextField ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (value.isEmpty() && placeholder.isNotEmpty()) {
                            Text(placeholder, color = Color.Gray.copy(alpha=0.5f), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                        innerTextField()
                    }
                }
            )
            if (subText != null) {
                Text(
                    text = subText,
                    color = Color(0xFFA0A0A0),
                    fontSize = 10.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun SMCTag(text: String, backgroundColor: Color, textColor: Color) {
    Box(
        modifier = Modifier
            .background(backgroundColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text = text, color = textColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
