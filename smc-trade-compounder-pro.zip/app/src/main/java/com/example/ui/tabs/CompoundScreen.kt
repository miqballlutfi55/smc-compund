package com.example.ui.tabs

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SMCHeader
import com.example.ui.SMCInputCard
import com.example.ui.SMCTextField
import com.example.ui.theme.*
import com.example.util.FormatUtils
import com.example.viewmodel.AppViewModel
import com.example.viewmodel.DailyProjection
import com.example.viewmodel.TradeResult

@Composable
fun CompoundScreen(viewModel: AppViewModel) {
    val state by viewModel.compoundState.collectAsState()
    val projections = remember(state) { viewModel.calculateProjections(state) }
    
    val currentKursIdr = state.kursIdr.toDoubleOrNull() ?: 16000.0
    val initBal = state.initialBalance.toDoubleOrNull() ?: 1000.0
    
    val finalBalance = projections.lastOrNull()?.endBalance ?: initBal
    val finalIdr = finalBalance * currentKursIdr
    val netProfit = finalBalance - initBal
    val netProfitIdr = netProfit * currentKursIdr
    
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    var isTimelineExpanded by remember { mutableStateOf(false) }
    
    var showSaveDialog by remember { mutableStateOf(false) }
    var planNameInput by remember { mutableStateOf("") }
    
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Plan") },
            text = {
                OutlinedTextField(
                    value = planNameInput,
                    onValueChange = { planNameInput = it },
                    label = { Text("Plan Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        focusedLabelColor = ElectricBlue
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (planNameInput.isNotBlank()) {
                        viewModel.saveCurrentPlan(planNameInput)
                        showSaveDialog = false
                        Toast.makeText(context, "Plan Saved Successfully!", Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Text("Save", color = ElectricBlue)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CardBackground,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF16161A)) // Dark grey-black background
            .padding(top = 16.dp)
    ) {
        // Pinned Header & Final Projection Card
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp, top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("SMC Calculator", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                    Text("COMPOUND PROJECTIONS", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    IconButton(
                        onClick = { isTimelineExpanded = !isTimelineExpanded },
                        modifier = Modifier
                            .background(Color.White, androidx.compose.foundation.shape.CircleShape)
                            .size(48.dp)
                    ) {
                        Icon(if (isTimelineExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, contentDescription = "Timeline", tint = Color.Black)
                    }
                }
            }
            
            if (!isTimelineExpanded) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            planNameInput = "Plan ${java.text.SimpleDateFormat("dd/MM", java.util.Locale.getDefault()).format(java.util.Date())} - ${state.totalTrades} Days"
                            showSaveDialog = true
                        },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFD6E2FE)),
                    shape = RoundedCornerShape(32.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 24.dp, horizontal = 16.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("FINAL PROJECTION", color = Color(0xFF38517B), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            FormatUtils.formatUsd(finalBalance),
                            color = Color(0xFF072960),
                            fontSize = 36.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = (-1).sp,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Rp ${FormatUtils.formatIdr(finalIdr).replace("Rp", "").trim()}",
                            color = Color(0xFF5774A3),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("PROFIT", color = Color(0xFF38517B), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                                Spacer(Modifier.height(2.dp))
                                Text("+${FormatUtils.formatUsd(netProfit)}", color = Color(0xFF1E8056), fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                Text("Rp ${FormatUtils.formatIdr(netProfitIdr).replace("Rp", "").trim()}", color = Color(0xFF1E8056).copy(alpha=0.8f), fontSize = 12.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("RETURN", color = Color(0xFF38517B), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                                Spacer(Modifier.height(2.dp))
                                val returnPct = if (initBal > 0) (netProfit / initBal) * 100 else 0.0
                                Text("+" + FormatUtils.formatPercent(returnPct) + "%", color = Color(0xFF072960), fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                Text("ROI", color = Color(0xFF5774A3), fontSize = 12.sp)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF072960), RoundedCornerShape(32.dp))
                                .padding(horizontal = 24.dp, vertical = 12.dp)
                        ) {
                            Text("+ SAVE STRATEGY PLAN", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Final Balance", color = TextSecondary, fontSize = 12.sp)
                        Text(FormatUtils.formatUsd(finalBalance), color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Net Profit", color = TextSecondary, fontSize = 12.sp)
                        Text("+${FormatUtils.formatUsd(netProfit)}", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            if (!isTimelineExpanded) {
                item {
                    val initBalIdrText = "≈ " + FormatUtils.formatIdr(initBal * currentKursIdr)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SMCInputCard("INITIAL (\$)", state.initialBalance, { viewModel.updateCompoundState { copy(initialBalance = it) } }, Modifier.weight(1f), subText = initBalIdrText, formatAsNumber = true)
                        SMCInputCard("PIPS TARGET", state.targetPips, { viewModel.updateCompoundState { copy(targetPips = it) } }, Modifier.weight(1f), formatAsNumber = true)
                        SMCInputCard("STEP SIZE (\$)", state.stepSize, { viewModel.updateCompoundState { copy(stepSize = it) } }, Modifier.weight(1f), formatAsNumber = true)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SMCInputCard("MAX LOT", state.maxLot, { viewModel.updateCompoundState { copy(maxLot = it) } }, Modifier.weight(1f), formatAsNumber = true)
                        SMCInputCard("TOTAL DAYS", state.totalTrades, { viewModel.updateCompoundState { copy(totalTrades = it) } }, Modifier.weight(1f), formatAsNumber = true)
                        SMCInputCard("INIT LOT", state.initialLot, { viewModel.updateCompoundState { copy(initialLot = it) } }, Modifier.weight(1f), placeholder = "Ops")
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SMCInputCard("AVG RISK:REWARD", state.rrRatio, { viewModel.updateCompoundState { copy(rrRatio = it) } }, Modifier.weight(1.5f), placeholder = "1.5 or 2")
                        SMCInputCard("KURS IDR", state.kursIdr, { viewModel.updateCompoundState { copy(kursIdr = it) } }, Modifier.weight(1f), formatAsNumber = true)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Loss = -${state.targetPips} pips", color = TextSecondary.copy(alpha=0.6f), fontSize = 12.sp)
                    Spacer(Modifier.height(24.dp))
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Timeline", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { 
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.clearOverrides() 
                        }) {
                            Text("Reset", color = ElectricBlue)
                        }
                        IconButton(onClick = { isTimelineExpanded = !isTimelineExpanded }) {
                            Icon(
                                if (isTimelineExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = "Toggle Full View",
                                tint = TextPrimary
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            items(projections) { proj ->
                ProjectionItem(proj, kursIdr = currentKursIdr, onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    val newResult = when(proj.result) {
                        TradeResult.PROJECTED -> TradeResult.WIN
                        TradeResult.WIN -> TradeResult.LOSS
                        TradeResult.LOSS -> TradeResult.PROJECTED
                    }
                    viewModel.setOverride(proj.day, newResult)
                })
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun ProjectionItem(proj: DailyProjection, kursIdr: Double, onClick: () -> Unit) {
    val isWin = proj.result == TradeResult.WIN
    val isLoss = proj.result == TradeResult.LOSS
    val isProjected = proj.result == TradeResult.PROJECTED

    val bgColor = when {
        isWin -> NeonGreen.copy(alpha = 0.05f)
        isLoss -> CrimsonRed.copy(alpha = 0.05f)
        else -> CardBackground
    }

    val outlineColor = when {
        isWin -> NeonGreen.copy(alpha = 0.3f)
        isLoss -> CrimsonRed.copy(alpha = 0.3f)
        else -> OutlineColor.copy(alpha=0.1f)
    }

    val indicatorColor = when {
        isWin -> NeonGreen
        isLoss -> CrimsonRed
        else -> TextSecondary.copy(alpha=0.5f)
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .clip(RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = BorderStroke(1.dp, outlineColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(4.dp, 40.dp)
                    .background(indicatorColor, RoundedCornerShape(2.dp))
            )
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("Day ${proj.day}", color = TextSecondary, fontSize = 12.sp)
                Text(
                    FormatUtils.formatUsd(proj.endBalance), 
                    color = TextPrimary, 
                    fontWeight = FontWeight.Bold, 
                    fontSize = 18.sp,
                    textDecoration = if(isLoss) TextDecoration.None else null
                )
                Text(FormatUtils.formatIdr(proj.endBalance * kursIdr), color=TextSecondary.copy(alpha=0.5f), fontSize=10.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${FormatUtils.formatLot(proj.lotSize)} Lot", color = ElectricBlue, fontWeight = FontWeight.Bold)
                
                val plText = if (proj.profitLoss > 0) "+${FormatUtils.formatUsd(proj.profitLoss)}" else FormatUtils.formatUsd(proj.profitLoss)
                Text(
                    text = plText, 
                    color = indicatorColor, 
                    fontSize = 14.sp,
                    textDecoration = if(isLoss) TextDecoration.LineThrough else null
                )
                Text(FormatUtils.formatIdr(Math.abs(proj.profitLoss) * kursIdr), color=indicatorColor.copy(alpha=0.6f), fontSize=10.sp)
            }
        }
    }
}

