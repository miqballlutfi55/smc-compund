package com.example.ui.tabs

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SMCHeader
import com.example.ui.theme.*
import com.example.util.FormatUtils
import com.example.viewmodel.AppViewModel

@Composable
fun AnalyticsScreen(viewModel: AppViewModel) {
    val state by viewModel.compoundState.collectAsState()
    val projections = remember(state) { viewModel.calculateProjections(state) }

    val startBalance = state.initialBalance.toDoubleOrNull() ?: 1000.0
    val finalBalance = projections.lastOrNull()?.endBalance ?: startBalance
    val maxBalance = maxOf(startBalance, projections.maxOfOrNull { it.endBalance } ?: startBalance)
    val minBalance = minOf(startBalance, projections.minOfOrNull { it.endBalance } ?: startBalance)
    
    val netProfit = finalBalance - startBalance
    val colors = if (netProfit >= 0) NeonGreen else CrimsonRed
    
    // Win Rate logic overrides
    val wins = projections.count { it.profitLoss > 0 }
    val total = projections.size
    val winRate = if (total > 0) (wins.toDouble() / total) * 100 else 0.0
    
    // Drawdown Calculation logic
    var maxDrawdown = 0.0
    var peak = startBalance
    for (p in projections) {
        if (p.endBalance > peak) {
            peak = p.endBalance
        }
        val currentDrawdown = ((peak - p.endBalance) / peak) * 100
        if (currentDrawdown > maxDrawdown) {
            maxDrawdown = currentDrawdown
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
    ) {
        SMCHeader("Analytics Curve")

        // Stats Row
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            StatCard("Net Profit", FormatUtils.formatUsd(netProfit), if (netProfit >= 0) NeonGreen else CrimsonRed, Modifier.weight(1f))
            StatCard("Win Rate", String.format("%.1f%%", winRate), ElectricBlue, Modifier.weight(1f))
            StatCard("Max DD", String.format("%.1f%%", maxDrawdown), CrimsonRed, Modifier.weight(1f))
        }
        
        Spacer(Modifier.height(32.dp))
        
        // Chart Area
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(bottom = 80.dp),
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(CardBackground, Color(0xFF15161A))))
                    .padding(24.dp)
            ) {
                if (projections.size > 1) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height
                        
                        val range = maxBalance - minBalance
                        val effectiveRange = if (range == 0.0) 1.0 else range
                        val paddingBottom = 40.dp.toPx()
                        val paddingStart = 100.dp.toPx()
                        
                        val chartWidth = width - paddingStart
                        val chartHeight = height - paddingBottom
                        
                        // Draw grid lines and Y-axis labels
                        val ySteps = 4
                        for (i in 0..ySteps) {
                            val yRatio = i.toFloat() / ySteps
                            val yPos = chartHeight - (yRatio * chartHeight)
                            val valueAtY = minBalance + (yRatio * effectiveRange)
                            
                            drawLine(
                                color = OutlineColor,
                                start = Offset(paddingStart, yPos),
                                end = Offset(width, yPos),
                                strokeWidth = 1.dp.toPx()
                            )
                            
                            drawContext.canvas.nativeCanvas.drawText(
                                "$" + FormatUtils.formatUsd(valueAtY).replace("$", ""),
                                0f,
                                yPos + 12f,
                                android.graphics.Paint().apply {
                                    color = android.graphics.Color.GRAY
                                    textSize = 28f
                                    textAlign = android.graphics.Paint.Align.LEFT
                                    isAntiAlias = true
                                }
                            )
                        }
                        
                        // X axis label (days)
                        drawLine(
                            color = OutlineColor,
                            start = Offset(paddingStart, chartHeight),
                            end = Offset(width, chartHeight),
                            strokeWidth = 2.dp.toPx()
                        )
                        
                        val xSteps = 5
                        for (i in 0..xSteps) {
                            val xRatio = i.toFloat() / xSteps
                            val xPos = paddingStart + (xRatio * chartWidth)
                            val dayVal = (xRatio * total).toInt()
                            
                            drawContext.canvas.nativeCanvas.drawText(
                                if (dayVal == 0) "Day 1" else "Day $dayVal",
                                xPos,
                                height - 10f,
                                android.graphics.Paint().apply {
                                    color = android.graphics.Color.GRAY
                                    textSize = 28f
                                    textAlign = android.graphics.Paint.Align.CENTER
                                    isAntiAlias = true
                                }
                            )
                        }
                        
                        // Draw Data Path
                        val points = mutableListOf<Offset>()
                        points.add(
                            Offset(
                                x = paddingStart,
                                y = chartHeight - ((startBalance - minBalance) / effectiveRange * chartHeight).toFloat()
                            )
                        )
                        
                        projections.forEachIndexed { i, proj ->
                            val x = paddingStart + ((i + 1).toFloat() / total * chartWidth)
                            val y = chartHeight - ((proj.endBalance - minBalance) / effectiveRange * chartHeight).toFloat()
                            points.add(Offset(x, y))
                        }
                        
                        val path = Path().apply {
                            moveTo(points.first().x, points.first().y)
                            for (i in 1 until points.size) {
                                lineTo(points[i].x, points[i].y)
                            }
                        }
                        
                        // Create gradient path for fill
                        val fillPath = Path().apply {
                            addPath(path)
                            lineTo(points.last().x, chartHeight)
                            lineTo(points.first().x, chartHeight)
                            close()
                        }
                        
                        drawPath(
                            path = fillPath,
                            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(colors.copy(alpha = 0.3f), Color.Transparent),
                                startY = 0f,
                                endY = chartHeight
                            )
                        )
                        
                        drawPath(
                            path = path,
                            color = colors,
                            style = Stroke(width = 4.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
                        )
                    }
                } else {
                    Text("Not enough data to calculate curve.", modifier = Modifier.align(Alignment.Center), color = TextSecondary)
                }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                value, 
                color = color, 
                fontWeight = FontWeight.Bold, 
                fontSize = 14.sp,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }
    }
}
